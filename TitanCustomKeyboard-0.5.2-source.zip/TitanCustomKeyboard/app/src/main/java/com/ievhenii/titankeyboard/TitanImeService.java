package com.ievhenii.titankeyboard;

import android.inputmethodservice.InputMethodService;
import android.view.KeyEvent;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.graphics.Color;
import android.graphics.Typeface;
import android.view.Gravity;
import android.widget.Toast;
import android.view.inputmethod.InputConnection;
import android.view.inputmethod.EditorInfo;
import android.os.Handler;
import android.os.Looper;
import android.content.SharedPreferences;
import java.util.HashMap;
import java.util.Map;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;

public class TitanImeService extends InputMethodService {
    private final Map<Integer,Long> down=new HashMap<>();
    private SharedPreferences prefs;
    private boolean alt=false,shiftLeft=false,shiftRight=false;
    private LinearLayout candidateBar;
    private final String[][] dictionaries = new String[][] {
        {"привет","как","что","это","да","нет","спасибо","пожалуйста","хорошо","сегодня","завтра","можно","нужно","будет","есть","я","ты","мы","вы","они","дом","работа","телефон","клавиатура","пхукет","тайланд","тай","пока","добрый","день","вечер","утро","время","сейчас","потом","если","потому","очень","только","сделать","сохранить","настройки","раскладка","слово","текст","сообщение","купить","цена","где","когда","почему","помоги","хочу","могу","надо","всё","все","мой","моя","твой","тебя","меня","буду","было","будет","может","нельзя","давай","ладно","ок"},
        {"привіт","як","що","це","так","ні","дякую","будь ласка","добре","сьогодні","завтра","можна","потрібно","буде","є","я","ти","ми","ви","вони","дім","робота","телефон","клавіатура","пхукет","таїланд","поки","добрий","день","вечір","ранок","час","зараз","потім","якщо","тому","дуже","тільки","зробити","зберегти","налаштування","розкладка","слово","текст","повідомлення","купити","ціна","де","коли","чому","допоможи","хочу","можу","треба","все","мій","моя","твій","тебе","мене","буду","було","може","не можна","давай","гаразд","ок"},
        {"hello","hi","how","what","this","that","yes","no","thanks","please","good","today","tomorrow","can","need","will","have","are","you","we","they","I","the","and","for","with","home","work","phone","keyboard","time","now","later","where","when","why","help","want","make","save","settings","layout","word","text","message","buy","price","please","okay","great","very","just","my","your","me","it","is","not","do","does","done","goodbye"}
    };
    private final Handler repeatHandler = new Handler(Looper.getMainLooper());
    private boolean deleteHeld = false;
    private final Runnable deleteRepeat = new Runnable() {
        @Override public void run() {
            if (!deleteHeld) return;
            deleteOne();
            int interval = prefs == null ? 100 : prefs.getInt("deleteRepeatMs", 100);
            repeatHandler.postDelayed(this, Math.max(30, interval));
        }
    };
    @Override public void onCreate(){super.onCreate();prefs=getSharedPreferences("keyboard",MODE_PRIVATE);}
    @Override public View onCreateInputView(){return new View(this);}
    @Override public View onCreateCandidatesView(){
        candidateBar=new LinearLayout(this);
        candidateBar.setOrientation(LinearLayout.HORIZONTAL);
        candidateBar.setGravity(Gravity.CENTER_VERTICAL);
        candidateBar.setPadding(4,2,4,2);
        candidateBar.setBackgroundColor(Color.rgb(245,247,250));
        return candidateBar;
    }
    @Override public boolean onEvaluateInputViewShown(){return false;}
    @Override public void onStartInput(EditorInfo attribute, boolean restarting){
        super.onStartInput(attribute,restarting);
        setCandidatesViewShown(true);
        refreshSuggestions();
    }
    @Override public boolean onEvaluateFullscreenMode(){return false;}

    @Override public boolean onKeyDown(int code,KeyEvent e){
        if(code==KeyEvent.KEYCODE_DEL){
            if(e.getRepeatCount()==0 && !deleteHeld){
                deleteHeld=true;
                deleteOne();
                int interval=prefs.getInt("deleteRepeatMs",100);
                repeatHandler.postDelayed(deleteRepeat,Math.max(30,interval));
            }
            return true;
        }
        if(code==KeyEvent.KEYCODE_ALT_LEFT||code==KeyEvent.KEYCODE_ALT_RIGHT){alt=true;return true;}
        if(code==KeyEvent.KEYCODE_SHIFT_LEFT){shiftLeft=true;return true;}
        if(code==KeyEvent.KEYCODE_SHIFT_RIGHT){shiftRight=true;return true;}
        if(isMapped(code)){if(e.getRepeatCount()==0)down.put(code,System.currentTimeMillis());return true;}
        return super.onKeyDown(code,e);
    }
    @Override public boolean onKeyUp(int code,KeyEvent e){
        if(code==KeyEvent.KEYCODE_DEL){
            deleteHeld=false;
            repeatHandler.removeCallbacks(deleteRepeat);
            return true;
        }
        if(code==KeyEvent.KEYCODE_ALT_LEFT||code==KeyEvent.KEYCODE_ALT_RIGHT){alt=false;return true;}
        if(code==KeyEvent.KEYCODE_SHIFT_LEFT){shiftLeft=false;return true;}
        if(code==KeyEvent.KEYCODE_SHIFT_RIGHT){shiftRight=false;return true;}
        if(code==KeyEvent.KEYCODE_SYM && (alt || e.isAltPressed())){
            int current=prefs.getInt("language",0);
            int next=(current==1)?0:((current==0)?2:1); // Русский -> Украинский -> English -> Русский
            prefs.edit().putInt("language",next).apply();
            String[] names={"Українська","Русский","English"};
            Toast.makeText(this,"Язык: "+names[next],Toast.LENGTH_SHORT).show();
            refreshSuggestions();
            return true;
        }
        if(!isMapped(code))return super.onKeyUp(code,e);
        Long start=down.remove(code);long ms=start==null?0:System.currentTimeMillis()-start;
        boolean useAlt=alt||e.isAltPressed(), useShift=shiftLeft||shiftRight||e.isShiftPressed();
        if(code==KeyEvent.KEYCODE_ENTER){handleEnter(useShift);return true;}
        int t1=prefs.getInt("hold500",500),t2=prefs.getInt("hold1000",1000);
        String out=null;
        if(t2>0&&ms>=t2)out=value(code,"hold1000");
        else if(t1>0&&ms>=t1)out=value(code,"hold500");
        if(out==null||out.isEmpty()){
            if(useAlt) {
                out=value(code,"alt");
                if(out==null||out.isEmpty()) out=altLegend(code);
            } else {
                out=value(code,"tap");
            }
        }
        if(out==null||out.isEmpty()) out=defaultValue(code);
        if(useShift && out!=null && !out.isEmpty()) out=out.toUpperCase(java.util.Locale.ROOT);
        if(out!=null&&!out.isEmpty())commit(out);
        return true;
    }
    private String value(int code,String layer){
        String saved=prefs.getString("key_"+code+"_"+layer,"");
        if(saved!=null&&!saved.isEmpty())return saved;
        if(code==KeyEvent.KEYCODE_U && layer.equals("alt"))return "_";
        if(code==KeyEvent.KEYCODE_L && layer.equals("hold500"))return "Ж";
        if(code==KeyEvent.KEYCODE_M && layer.equals("hold500"))return "ь";
        if(code==KeyEvent.KEYCODE_S && layer.equals("hold500"))return "ы";
        if(layer.equals("hold1000")){
            switch(code){
                case KeyEvent.KEYCODE_Q:return "0"; case KeyEvent.KEYCODE_R:return "3";
                case KeyEvent.KEYCODE_S:return "4"; case KeyEvent.KEYCODE_W:return "1";
                case KeyEvent.KEYCODE_X:return "8"; case KeyEvent.KEYCODE_Z:return "7";
                case KeyEvent.KEYCODE_C:return "9"; case KeyEvent.KEYCODE_D:return "5";
                case KeyEvent.KEYCODE_E:return "2"; case KeyEvent.KEYCODE_F:return "6";
            }
        }
        return "";
    }
    private void handleEnter(boolean shifted){InputConnection ic=getCurrentInputConnection();if(ic==null)return;if(shifted){ic.commitText("\n",1);return;}EditorInfo info=getCurrentInputEditorInfo();if(info!=null&&info.actionId!=0){ic.performEditorAction(info.actionId);return;}int action=info==null?EditorInfo.IME_ACTION_NONE:info.imeOptions&EditorInfo.IME_MASK_ACTION;if(action!=EditorInfo.IME_ACTION_NONE&&action!=EditorInfo.IME_ACTION_UNSPECIFIED)ic.performEditorAction(action);else ic.commitText("\n",1);}
    private void commit(String s){
        InputConnection ic=getCurrentInputConnection();
        if(ic!=null){
            ic.commitText(s,1);
            learnAndRefresh(s);
        }
    }
    private void learnAndRefresh(String inserted){
        if(inserted==null)return;
        if(inserted.matches(".*[\\s.,!?;:()\\[\\]{}].*")){
            String before="";
            InputConnection ic=getCurrentInputConnection();
            if(ic!=null){CharSequence q=ic.getTextBeforeCursor(80,0);if(q!=null)before=q.toString();}
            java.util.regex.Matcher m=java.util.regex.Pattern.compile("([\\p{L}]{2,})[\\s.,!?;:()\\[\\]{}]$").matcher(before);
            if(m.find()){
                String word=m.group(1).toLowerCase(java.util.Locale.ROOT);
                int n=prefs.getInt("word_"+word,0);
                prefs.edit().putInt("word_"+word,Math.min(10000,n+1)).apply();
            }
        }
        refreshSuggestions();
    }
    private void refreshSuggestions(){
        if(candidateBar==null)return;
        candidateBar.removeAllViews();
        InputConnection ic=getCurrentInputConnection();
        String before="";
        if(ic!=null){CharSequence q=ic.getTextBeforeCursor(80,0);if(q!=null)before=q.toString();}
        java.util.regex.Matcher m=java.util.regex.Pattern.compile("([\\p{L}]{1,})$").matcher(before);
        String prefix=m.find()?m.group(1).toLowerCase(java.util.Locale.ROOT):"";
        if(prefix.isEmpty()){
            String[] shortNames={"UA","RU","EN"};
            TextView langHint=new TextView(this);
            langHint.setText("ALT+SYM  "+shortNames[Math.max(0,Math.min(2,prefs.getInt("language",0)))]);
            langHint.setTextColor(0xff657084);langHint.setTextSize(10);langHint.setGravity(Gravity.CENTER);
            langHint.setPadding(6,4,6,4);
            candidateBar.addView(langHint,new LinearLayout.LayoutParams(-2,-2));
            setCandidatesViewShown(true);return;
        }
        int lang=prefs==null?0:prefs.getInt("language",0);
        java.util.LinkedHashSet<String> pool=new java.util.LinkedHashSet<>();
        for(String w:dictionaries[Math.max(0,Math.min(2,lang))]) if(w.startsWith(prefix)) pool.add(w);
        Map<String,Integer> learned=new HashMap<>();
        if(prefs!=null) for(Map.Entry<String,?> e:prefs.getAll().entrySet()){
            if(e.getKey().startsWith("word_") && e.getValue() instanceof Integer){
                String w=e.getKey().substring(5);
                if(w.startsWith(prefix)) learned.put(w,(Integer)e.getValue());
            }
        }
        for(String w:learned.keySet())pool.add(w);
        ArrayList<String> results=new ArrayList<>(pool);
        Collections.sort(results,new Comparator<String>(){
            public int compare(String a,String b){
                int fa=learned.containsKey(a)?learned.get(a):0;
                int fb=learned.containsKey(b)?learned.get(b):0;
                if(fa!=fb)return Integer.compare(fb,fa);
                return Integer.compare(a.length(),b.length());
            }
        });
        for(int i=0;i<Math.min(3,results.size());i++){
            final String word=results.get(i);
            TextView t=new TextView(this);t.setText(word);t.setTextColor(0xff172033);t.setTextSize(16);t.setGravity(Gravity.CENTER);
            t.setTypeface(null,Typeface.NORMAL);t.setPadding(8,8,8,8);
            candidateBar.addView(t,new LinearLayout.LayoutParams(0,-2,1));
            t.setOnClickListener(v->{
                InputConnection c=getCurrentInputConnection();
                if(c!=null){
                    c.deleteSurroundingText(prefix.length(),0);
                    c.commitText(word,1);
                    int count=prefs.getInt("word_"+word,0);
                    prefs.edit().putInt("word_"+word,Math.min(10000,count+3)).apply();
                    refreshSuggestions();
                }
            });
        }
        String[] shortNames={"UA","RU","EN"};
        TextView langHint=new TextView(this);
        langHint.setText("ALT+SYM  "+shortNames[Math.max(0,Math.min(2,lang))]);
        langHint.setTextColor(0xff657084);
        langHint.setTextSize(10);
        langHint.setGravity(Gravity.CENTER);
        langHint.setPadding(5,4,5,4);
        candidateBar.addView(langHint,new LinearLayout.LayoutParams(-2,-2));
        setCandidatesViewShown(true);
    }
    private void deleteOne(){
        InputConnection ic=getCurrentInputConnection();
        if(ic!=null) ic.deleteSurroundingText(1,0);
        refreshSuggestions();
    }
    @Override public void onFinishInput(){
        deleteHeld=false;
        repeatHandler.removeCallbacks(deleteRepeat);
        super.onFinishInput();
    }
    private boolean isMapped(int k){return (k>=KeyEvent.KEYCODE_A&&k<=KeyEvent.KEYCODE_Z)||k==KeyEvent.KEYCODE_SPACE||k==KeyEvent.KEYCODE_SYM||k==KeyEvent.KEYCODE_ENTER||k==KeyEvent.KEYCODE_DEL;}
    private String defaultValue(int code){
        if(code==KeyEvent.KEYCODE_SPACE)return " ";
        if(code==KeyEvent.KEYCODE_SYM)return "ю";
        if(code>=KeyEvent.KEYCODE_A&&code<=KeyEvent.KEYCODE_Z){char en=(char)('a'+code-KeyEvent.KEYCODE_A);int lang=prefs.getInt("language",0);if(lang==2)return String.valueOf(en);String keys="qwertyuiopasdfghjklzxcvbnm",ua="йцукенгшщзфівапролдячсмить",ru="йцукенгшщзфывапролдячсмить";int i=keys.indexOf(en);String m=lang==0?ua:ru;return i>=0&&i<m.length()?String.valueOf(m.charAt(i)):String.valueOf(en);}
        return "";
    }
    private String altLegend(int code){if(code<KeyEvent.KEYCODE_A||code>KeyEvent.KEYCODE_Z)return null;char c=(char)('a'+code-KeyEvent.KEYCODE_A);switch(c){case'q':return"0";case'w':return"1";case'e':return"2";case'r':return"3";case't':return"(";case'y':return")";case'u':return"_";case'i':return null;case'o':return"+";case'p':return"0";case'a':return"*";case's':return"4";case'd':return"5";case'f':return"6";case'g':return"/";case'h':return":";case'j':return"#";case'k':return"'";case'l':return"\"";case'z':return"7";case'x':return"8";case'c':return"9";case'v':return"?";case'b':return"!";case'n':return",";case'm':return".";}return null;}
}
