package com.ievhenii.titankeyboard;

import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.provider.Settings;
import android.graphics.Typeface;
import android.text.InputType;
import android.view.KeyEvent;
import android.widget.*;
import java.util.*;

public class MainActivity extends Activity {
    private SharedPreferences p;
    private LinearLayout root, rowsRoot;
    private boolean detecting=false;
    private TextView detectStatus;
    private final List<Row> rows=new ArrayList<>();
    static class Row { int code; String label; EditText[] f=new EditText[6]; Row(int c,String l){code=c;label=l;} }
    private static final int[] CODES=new int[28];
    private static final String[] NAMES=new String[28];
    static {
        String alphabet="ABCDEFGHIJKLMNOPQRSTUVWXYZ";
        for(int i=0;i<26;i++){ CODES[i]=29+i; NAMES[i]=String.valueOf(alphabet.charAt(i)); }
        CODES[26]=62; NAMES[26]="Пробел";
        CODES[27]=63; NAMES[27]="SYM — ю";
    }
    private final String[] layers={"tap","alt","sym","shift","hold500","hold1000"};
    private final String[] hints={"Коротко","ALT","SYM","SHIFT","0,5 сек","1 сек"};
    @Override public void onCreate(Bundle b){super.onCreate(b);p=getSharedPreferences("keyboard",MODE_PRIVATE);build();}
    @Override public boolean dispatchKeyEvent(KeyEvent e){
        if(detecting && e.getAction()==KeyEvent.ACTION_DOWN && e.getRepeatCount()==0){
            int c=e.getKeyCode(); detecting=false;
            detectStatus.setText("Определена клавиша: "+KeyEvent.keyCodeToString(c)+" (код "+c+")"+(isExcluded(c)?" — исключена из списка по настройкам":""));
            return true;
        }
        return super.dispatchKeyEvent(e);
    }
    private boolean isExcluded(int c){return (c>=7&&c<=16)||(c>=68&&c<=76)||c==55||c==56;}
    private void build(){
        ScrollView sv=new ScrollView(this); root=new LinearLayout(this); root.setOrientation(1); root.setPadding(20,18,20,30); sv.addView(root); root.setBackgroundColor(0xfff3f5f8); setContentView(sv);
        root.addView(label("Titan Custom Keyboard 0.4.6",24,true)); root.addView(label("Редактор физических клавиш Titan 2 Elite",14,false));
        section("Профиль языка"); Spinner lang=new Spinner(this); lang.setAdapter(new ArrayAdapter<>(this,android.R.layout.simple_spinner_dropdown_item,new String[]{"Українська","Русский","English"})); lang.setSelection(p.getInt("language",0)); root.addView(lang);
        section("Удержание — независимые таймеры"); addTimer("hold500","Удержание 1 (мс)",500); addTimer("hold1000","Удержание 2 (мс)",1000);
        section("Повтор удаления"); addDeleteRepeatSetting();
        section("Определение физической клавиши"); Button detect=new Button(this); detect.setText("ОПРЕДЕЛИТЬ КЛАВИШУ — НАЖМИ НА НЕЁ НА ТЕЛЕФОНЕ"); root.addView(detect); detectStatus=label("Ожидание",13,false); root.addView(detectStatus); detect.setOnClickListener(v->{detecting=true;detectStatus.setText("Теперь нажми физическую клавишу Titan 2 Elite");});
        section("Физические модификаторы");
        root.addView(label("ALT Left — 57 · SHIFT Left — 59 · SHIFT Right — 60 · SPACE — 62 · SYM — 63 (обычная клавиша: ю / Shift+SYM: Ю). Оба SHIFT только переключают заглавные буквы.",13,false));
        section("Назначения клавиш"); root.addView(label("Коротко | ALT | SYM-слой (для старых назначений) | SHIFT | 0,5 сек. | 1 сек.",12,true)); rowsRoot=new LinearLayout(this); rowsRoot.setOrientation(1); root.addView(rowsRoot);
        for(int i=0;i<CODES.length;i++) addRow(CODES[i],NAMES[i]);
        section("Функции SHIFT"); root.addView(label("Левый и правый SHIFT работают одинаково: только заглавные буквы. SYM (код 63) по умолчанию вводит ю, с Shift — Ю. ALT — цифры и спецсимволы.",13,false));
        Button save=new Button(this); save.setText("СОХРАНИТЬ ВСЕ НАСТРОЙКИ"); root.addView(save); save.setOnClickListener(v->{SharedPreferences.Editor ed=p.edit().putInt("language",lang.getSelectedItemPosition()); for(Row r:rows)for(int j=0;j<layers.length;j++)ed.putString(key(r.code,layers[j]),r.f[j].getText().toString()); ed.apply(); Toast.makeText(this,"Сохранено",Toast.LENGTH_SHORT).show();});
        Button ime=new Button(this); ime.setText("НАСТРОЙКИ КЛАВИАТУР ANDROID"); root.addView(ime); ime.setOnClickListener(v->startActivity(new Intent(Settings.ACTION_INPUT_METHOD_SETTINGS)));
        Button reset=new Button(this); reset.setText("СБРОСИТЬ НАЗНАЧЕНИЯ"); root.addView(reset); reset.setOnClickListener(v->new android.app.AlertDialog.Builder(this).setMessage("Сбросить все назначения?").setNegativeButton("Отмена",null).setPositiveButton("Сбросить",(d,w)->{p.edit().clear().apply();recreate();}).show());
    }
    private void addDeleteRepeatSetting(){
        int min=30, max=1000, def=100;
        LinearLayout box=new LinearLayout(this); box.setOrientation(1); root.addView(box);
        TextView val=label("Интервал повтора Delete: "+p.getInt("deleteRepeatMs",def)+" мс",13,false); box.addView(val);
        SeekBar seek=new SeekBar(this); seek.setMax(max-min); seek.setProgress(Math.max(0,Math.min(max-min,p.getInt("deleteRepeatMs",def)-min))); box.addView(seek);
        box.addView(label("Меньше значение — быстрее удаление. Диапазон 30–1000 мс.",11,false));
        seek.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener(){
            public void onProgressChanged(SeekBar b,int n,boolean user){val.setText("Интервал повтора Delete: "+(n+min)+" мс");}
            public void onStartTrackingTouch(SeekBar b){}
            public void onStopTrackingTouch(SeekBar b){p.edit().putInt("deleteRepeatMs",b.getProgress()+min).apply();}
        });
    }
    private void addTimer(String key,String title,int def){LinearLayout box=new LinearLayout(this);box.setOrientation(1);root.addView(box);TextView val=label(title+": "+p.getInt(key,def),13,false);box.addView(val);SeekBar s=new SeekBar(this);s.setMax(3000);s.setProgress(p.getInt(key,def));box.addView(s);s.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener(){public void onProgressChanged(SeekBar b,int n,boolean u){val.setText(title+": "+n+" мс (0 = выкл.)");}public void onStartTrackingTouch(SeekBar b){}public void onStopTrackingTouch(SeekBar b){p.edit().putInt(key,b.getProgress()).apply();}});}
    private void addRow(int code,String name){Row r=new Row(code,name);rows.add(r);LinearLayout card=new LinearLayout(this);card.setOrientation(1);card.setPadding(8,6,8,8);card.setBackgroundColor(0xffffffff);LinearLayout.LayoutParams cp=new LinearLayout.LayoutParams(-1,-2);cp.bottomMargin=5;rowsRoot.addView(card,cp);card.addView(label(name+" • Android keycode "+code,14,true));LinearLayout line=new LinearLayout(this);card.addView(line);for(int j=0;j<layers.length;j++){LinearLayout col=new LinearLayout(this);col.setOrientation(1);col.setPadding(2,0,2,0);line.addView(col,new LinearLayout.LayoutParams(0,-2,1));col.addView(label(hints[j],10,false));EditText e=new EditText(this);e.setSingleLine(true);e.setTextSize(13);e.setPadding(3,0,3,0);e.setInputType(InputType.TYPE_CLASS_TEXT|InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS);e.setHint("—");e.setText(p.getString(key(code,layers[j]),defaultFor(code,layers[j])));col.addView(e,new LinearLayout.LayoutParams(-1,42));r.f[j]=e;}}
    private String defaultFor(int code,String layer){
        if(code==63 && layer.equals("tap"))return "ю";
        if(layer.equals("alt")){if(code>=29&&code<=54){char c=(char)('a'+code-29);String sym=altLegend(c);if(sym!=null)return sym;}return "";}
        // Left SHIFT is handled as uppercase in the IME; do not preload symbol legends here.
        if(layer.equals("shift"))return "";
        return "";
    }
    private String altLegend(char c){switch(c){case'q':return"0";case'w':return"1";case'e':return"2";case'r':return"3";case't':return"(";case'y':return")";case'u':return"-";case'i':return"_";case'o':return"+";case'p':return"@";case'a':return"*";case's':return"4";case'd':return"5";case'f':return"6";case'g':return"/";case'h':return":";case'j':return"#";case'k':return"'";case'l':return"\"";case'z':return"7";case'x':return"8";case'c':return"9";case'v':return"?";case'b':return"!";case'n':return"'";case'm':return".";}return null;}
    private String key(int c,String l){return "key_"+c+"_"+l;} private void section(String s){TextView t=label(s,17,true);t.setPadding(0,18,0,6);root.addView(t);} private TextView label(String s,int size,boolean bold){TextView t=new TextView(this);t.setText(s);t.setTextSize(size);t.setTextColor(0xff172033);if(bold)t.setTypeface(null,Typeface.BOLD);return t;}
}
