package com.ievhenii.titankeyboard;

import android.inputmethodservice.InputMethodService;
import android.view.KeyEvent;
import android.view.View;
import android.view.inputmethod.InputConnection;
import android.view.inputmethod.EditorInfo;
import android.os.Handler;
import android.os.Looper;
import android.content.SharedPreferences;
import java.util.HashMap;
import java.util.Map;

public class TitanImeService extends InputMethodService {
    private final Map<Integer,Long> down=new HashMap<>();
    private SharedPreferences prefs;
    private boolean alt=false,shiftLeft=false,shiftRight=false;
    private final Handler repeatHandler = new Handler(Looper.getMainLooper());
    private boolean deleteHeld = false;
    private final Runnable deleteRepeat = new Runnable() {
        @Override public void run() {
            if (!deleteHeld) return;
            deleteOne();
            int interval = prefs == null ? 100 : prefs.getInt("deleteRepeatMs", 100);
            repeatHandler.postDelayed(this, Math.max(30, interval));
        }
    };
    @Override public void onCreate(){super.onCreate();prefs=getSharedPreferences("keyboard",MODE_PRIVATE);}
    @Override public View onCreateInputView(){return new View(this);}
    @Override public boolean onEvaluateInputViewShown(){return false;}
    @Override public boolean onEvaluateFullscreenMode(){return false;}

    @Override public boolean onKeyDown(int code,KeyEvent e){
        if(code==KeyEvent.KEYCODE_DEL){
            if(e.getRepeatCount()==0 && !deleteHeld){
                deleteHeld=true;
                deleteOne();
                int interval=prefs.getInt("deleteRepeatMs",100);
                repeatHandler.postDelayed(deleteRepeat,Math.max(30,interval));
            }
            return true;
        }
        if(code==KeyEvent.KEYCODE_ALT_LEFT||code==KeyEvent.KEYCODE_ALT_RIGHT){alt=true;return true;}
        if(code==KeyEvent.KEYCODE_SHIFT_LEFT){shiftLeft=true;return true;}
        if(code==KeyEvent.KEYCODE_SHIFT_RIGHT){shiftRight=true;return true;}
        if(isMapped(code)){if(e.getRepeatCount()==0)down.put(code,System.currentTimeMillis());return true;}
        return super.onKeyDown(code,e);
    }
    @Override public boolean onKeyUp(int code,KeyEvent e){
        if(code==KeyEvent.KEYCODE_DEL){
            deleteHeld=false;
            repeatHandler.removeCallbacks(deleteRepeat);
            return true;
        }
        if(code==KeyEvent.KEYCODE_ALT_LEFT||code==KeyEvent.KEYCODE_ALT_RIGHT){alt=false;return true;}
        if(code==KeyEvent.KEYCODE_SHIFT_LEFT){shiftLeft=false;return true;}
        if(code==KeyEvent.KEYCODE_SHIFT_RIGHT){shiftRight=false;return true;}
        if(!isMapped(code))return super.onKeyUp(code,e);
        Long start=down.remove(code);long ms=start==null?0:System.currentTimeMillis()-start;
        boolean useAlt=alt||e.isAltPressed(), useShift=shiftLeft||shiftRight||e.isShiftPressed();
        if(code==KeyEvent.KEYCODE_ENTER){handleEnter(useShift);return true;}
        int t1=prefs.getInt("hold500",500),t2=prefs.getInt("hold1000",1000);
        String out=null;
        if(t2>0&&ms>=t2)out=value(code,"hold1000");
        else if(t1>0&&ms>=t1)out=value(code,"hold500");
        if(out==null||out.isEmpty()){
            if(useAlt) {
                out=value(code,"alt");
                if(out==null||out.isEmpty()) out=altLegend(code);
            } else {
                out=value(code,"tap");
            }
        }
        if(out==null||out.isEmpty()) out=defaultValue(code);
        if(useShift && out!=null && !out.isEmpty()) out=out.toUpperCase(java.util.Locale.ROOT);
        if(out!=null&&!out.isEmpty())commit(out);
        return true;
    }
    private String value(int code,String layer){return prefs.getString("key_"+code+"_"+layer,"");}
    private void handleEnter(boolean shifted){InputConnection ic=getCurrentInputConnection();if(ic==null)return;if(shifted){ic.commitText("\n",1);return;}EditorInfo info=getCurrentInputEditorInfo();if(info!=null&&info.actionId!=0){ic.performEditorAction(info.actionId);return;}int action=info==null?EditorInfo.IME_ACTION_NONE:info.imeOptions&EditorInfo.IME_MASK_ACTION;if(action!=EditorInfo.IME_ACTION_NONE&&action!=EditorInfo.IME_ACTION_UNSPECIFIED)ic.performEditorAction(action);else ic.commitText("\n",1);}
    private void commit(String s){InputConnection ic=getCurrentInputConnection();if(ic!=null)ic.commitText(s,1);}
    private void deleteOne(){
        InputConnection ic=getCurrentInputConnection();
        if(ic!=null) ic.deleteSurroundingText(1,0);
    }
    @Override public void onFinishInput(){
        deleteHeld=false;
        repeatHandler.removeCallbacks(deleteRepeat);
        super.onFinishInput();
    }
    private boolean isMapped(int k){return (k>=KeyEvent.KEYCODE_A&&k<=KeyEvent.KEYCODE_Z)||k==KeyEvent.KEYCODE_SPACE||k==KeyEvent.KEYCODE_SYM||k==KeyEvent.KEYCODE_ENTER||k==KeyEvent.KEYCODE_DEL;}
    private String defaultValue(int code){
        if(code==KeyEvent.KEYCODE_SPACE)return " ";
        if(code==KeyEvent.KEYCODE_SYM)return "ю";
        if(code>=KeyEvent.KEYCODE_A&&code<=KeyEvent.KEYCODE_Z){char en=(char)('a'+code-KeyEvent.KEYCODE_A);int lang=prefs.getInt("language",0);if(lang==2)return String.valueOf(en);String keys="qwertyuiopasdfghjklzxcvbnm",ua="йцукенгшщзфівапролдячсмить",ru="йцукенгшщзфывапролдячсмить";int i=keys.indexOf(en);String m=lang==0?ua:ru;return i>=0&&i<m.length()?String.valueOf(m.charAt(i)):String.valueOf(en);}
        return "";
    }
    private String altLegend(int code){if(code<KeyEvent.KEYCODE_A||code>KeyEvent.KEYCODE_Z)return null;char c=(char)('a'+code-KeyEvent.KEYCODE_A);switch(c){case'q':return"0";case'w':return"1";case'e':return"2";case'r':return"3";case't':return"(";case'y':return")";case'u':return"-";case'i':return"_";case'o':return"+";case'p':return"@";case'a':return"*";case's':return"4";case'd':return"5";case'f':return"6";case'g':return"/";case'h':return":";case'j':return"#";case'k':return"'";case'l':return"\"";case'z':return"7";case'x':return"8";case'c':return"9";case'v':return"?";case'b':return"!";case'n':return"'";case'm':return".";}return null;}
}
